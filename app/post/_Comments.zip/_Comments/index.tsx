//import "app/base.css"
import "./Comment.modules.css"

import { Post } from "@prisma/client"
import { usePost } from "hooks/usePost"
import { getComments } from "lib/metrics"
import { CompletePost } from "prisma/ZOD"
import { memo, Suspense, useState } from "react"
import { api } from "server/trpc/rpc_client"
import type { Comment, PostX } from "types"

import { CommentForm } from "./Form"
import { CommentList } from "./List"
import { CommentSolo } from "./Single"
import { root } from ".eslintrc.cjs"

const CommentComponent = async ({ slug }: { slug: string }) => {
  //const [error, setError] = useState("")
  const post = await getComments(slug)

  const rootComments = post.comments?.filter(
    (comment) => (comment.parentId === null)
  )  
  
 // const count = post.comments

return (
    <>
      {/* <div className="justify-start text-xs">{count}</div> */}
      <h2 className="p-4 text-center text-xl font-bold text-gray-800">
        Comments
      </h2>
      <CommentForm />
      {/* <CommentForm onSubmit={handleCommentCreate} error={error} /> */}
      {/*         {rootComments.map((rootComment) => (
          <CommentSolo
            key={rootComment.id}
            comment={rootComment}
            replies={getReplies(rootComment.id)}

          />
        ))}  */}
        {rootComments && (
      <CommentList comments={rootComments} />
        )}
    </>
)
}

export default CommentComponent
